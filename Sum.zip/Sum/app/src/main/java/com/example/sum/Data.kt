package com.example.sum

data class Task(val id: Int, var name: String)